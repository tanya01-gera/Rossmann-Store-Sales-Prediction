import streamlit as st
import numpy as np
import pandas as pd
import joblib
from tensorflow.keras.models import load_model

# Load model and scaler
model = load_model("lstm_model.h5", compile=False)

scaler = joblib.load("scaler.pkl")

st.title("Rossmann Store Sales Prediction")

st.write("Enter Store Features Below:")

# Example inputs (adjust if needed)
store = st.number_input("Store ID", min_value=1)
day_of_week = st.slider("Day of Week", 1, 7)
promo = st.selectbox("Promo", [0, 1])
school_holiday = st.selectbox("School Holiday", [0, 1])
customers = st.number_input("Customers", min_value=0)

# When button is clicked
if st.button("Predict Sales"):

    # Create dataframe
    input_data = pd.DataFrame([[
        store,
        day_of_week,
        promo,
        school_holiday,
        customers
    ]], columns=[
        "Store",
        "DayOfWeek",
        "Promo",
        "SchoolHoliday",
        "Customers"
    ])

    # Scale
    input_scaled = scaler.transform(input_data)

    # Reshape for LSTM
    input_scaled = np.reshape(input_scaled, (1, 1, input_scaled.shape[1]))

    prediction = model.predict(input_scaled)

    st.success(f"Predicted Sales: ₹ {prediction[0][0]:,.2f}")
